$(document).ready(function () {

    

    // $('#video-list1').click(function() {
    //     alert('oi')
    //     //run function that records clicks
    // });
    
    // $('.video-list iframe').click(function () {
    //     $(this).addClass('active').siblings().removeClass('active');
    //     let src = $(this).attr('src')
    //     $('.main-video iframe').attr('src', src)
    //     playButton.classList.add('paused');
    // })

    // const iconVideoList1 = document.getElementById('icon-video-list1');
    // const iconVideoList2 = document.getElementById('icon-video-list2');
    // const iconVideoList3 = document.getElementById('icon-video-list3');
    // const iconVideoList4 = document.getElementById('icon-video-list4');
    // const iconVideoList5 = document.getElementById('icon-video-list5');
    // const iconVideoList6 = document.getElementById('icon-video-list6');

    // iconVideoList1.addEventListener('click', () => {
    //     $(this).addClass('active').siblings().removeClass('active');
    //     let src = '/videos/Instalacao Gravata_alta.mp4';
    //     $('.main-video video').attr('src', src)
    //     playButton.classList.add('paused');
    // });

    // iconVideoList2.addEventListener('click', () => {
    //     $(this).addClass('active').siblings().removeClass('active');
    //     let src = "/videos/Instalacao Varzea_alta resolucao.mp4";;
    //     $('.main-video video').attr('src', src)
    //     playButton.classList.add('paused');
    // });

    // iconVideoList3.addEventListener('click', () => {
    //     $(this).addClass('active').siblings().removeClass('active');
    //     let src = "/videos/Itamaraca Instalacao Forte.mp4";
    //     $('.main-video video').attr('src', src)
    //     playButton.classList.add('paused');
    // });

    // iconVideoList4.addEventListener('click', () => {
    //     $(this).addClass('active').siblings().removeClass('active');
    //     let src = "/videos/TOQUINHO FILMAGEM INSTALACAO.mp4";
    //     $('.main-video video').attr('src', src)
    //     playButton.classList.add('paused');
    // });

    // iconVideoList5.addEventListener('click', () => {
    //     $(this).addClass('active').siblings().removeClass('active');
    //     let src = "/videos/Video Ronaldo _Praia Sossego_Alta Definicao.mp4";
    //     $('.main-video video').attr('src', src)
    //     playButton.classList.add('paused');
    // });

    // iconVideoList6.addEventListener('click', () => {
    //     $(this).addClass('active').siblings().removeClass('active');
    //     let src = "/videos/Video Torreao.mp4";
    //     $('.main-video video').attr('src', src)
    //     playButton.classList.add('paused');
    // });


})